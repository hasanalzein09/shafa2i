// /home/ubuntu/shafa2i_project/frontend/admin-web/src/app/content/page.tsx
// Page for managing content like announcements, offers, etc.

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { getContentItems, addContentItem, updateContentItem, deleteContentItem } from '@/services/apiClient'; // Import actual API functions

export default function AdminContentPage() {
  const { toast } = useToast();
  const [contentItems, setContentItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContent, setEditingContent] = useState(null); // null for new, content object for editing
  const [formData, setFormData] = useState({ title: '', body: '', content_type: 'announcement', target_audience: 'all' }); // Default values
  const [formLoading, setFormLoading] = useState(false);

  const fetchContent = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching content items...');
      // Use actual API call
      const data = await getContentItems();
      setContentItems(data || []); // Ensure it's an array
    } catch (err) {
      console.error('Failed to fetch content:', err);
      const errorMsg = err.response?.data?.detail || 'Failed to load content items.';
      setError(errorMsg);
      toast({ title: "Error Loading Content", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const openDialog = (content = null) => {
    setEditingContent(content);
    if (content) {
      setFormData({
        title: content.title || '',
        body: content.body || '',
        content_type: content.content_type || 'announcement',
        target_audience: content.target_audience || 'all',
      });
    } else {
      setFormData({ title: '', body: '', content_type: 'announcement', target_audience: 'all' }); // Reset for new content
    }
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingContent(null);
    setFormData({ title: '', body: '', content_type: 'announcement', target_audience: 'all' });
    setFormLoading(false); // Reset form loading state
  };

  const handleFormSubmit = async () => {
    setFormLoading(true);
    setError(null);
    try {
      const contentData = { ...formData };

      if (editingContent) {
        console.log(`Updating content ${editingContent.id} with:`, contentData);
        // Use actual API call for update
        await updateContentItem(editingContent.id, contentData);
        toast({ title: "Content Updated", description: "Content item saved successfully." });
      } else {
        console.log('Adding new content:', contentData);
        // Use actual API call for add
        await addContentItem(contentData);
        toast({ title: "Content Added", description: "New content item created successfully." });
      }
      fetchContent(); // Refresh list
      closeDialog();
    } catch (err) {
      console.error('Failed to save content:', err);
      const errorMsg = err.response?.data?.detail || `Failed to ${editingContent ? 'update' : 'add'} content item.`;
      setError(errorMsg);
      toast({ title: "Save Failed", description: errorMsg, variant: "destructive" });
      // Keep dialog open on error
      setFormLoading(false);
    }
    // Note: finally block removed to keep dialog open on error
  };

  const handleDelete = async (contentId) => {
    if (!confirm('Are you sure you want to delete this content item? This cannot be undone.')) return;

    try {
      console.log('Deleting content item:', contentId);
      // Use actual API call
      await deleteContentItem(contentId);
      toast({ title: "Content Deleted", description: "The content item has been removed." });
      fetchContent(); // Refresh list
    } catch (err) {
      console.error('Failed to delete content:', err);
      const errorMsg = err.response?.data?.detail || 'Could not delete content item.';
      toast({ title: "Deletion Failed", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
    }
  };

  return (
    <div className="container mx-auto p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Content Management</h1>
        <Button onClick={() => openDialog()}>Add New Content</Button>
      </div>

      {error && !isDialogOpen && <p className="text-red-500 mb-4">Error: {error}</p>} {/* Show general error only when dialog is closed */}

      <Card>
        <CardHeader>
          <CardTitle>Content Items</CardTitle>
          <CardDescription>Manage announcements, offers, and other content.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading content...</p>
          ) : contentItems.length === 0 ? (
            <p>No content items found.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Audience</TableHead>
                  <TableHead>Created At</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {/* Adjust fields based on actual API response */}
                {contentItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell className="capitalize">{item.content_type}</TableCell>
                    <TableCell className="capitalize">{item.target_audience}</TableCell>
                    <TableCell>{new Date(item.created_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="outline" size="sm" onClick={() => openDialog(item)}>Edit</Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDelete(item.id)}>Delete</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Content Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingContent ? 'Edit Content' : 'Add New Content'}</DialogTitle>
            <DialogDescription>
              {editingContent ? 'Update the details of the content item.' : 'Enter the details for the new content item.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {error && isDialogOpen && <p className="text-red-500 text-sm">Error: {error}</p>} {/* Show form-specific error */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="title" className="text-right">Title</Label>
              <Input id="title" value={formData.title} onChange={handleInputChange} className="col-span-3" disabled={formLoading} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="body" className="text-right">Body</Label>
              <Textarea id="body" value={formData.body} onChange={handleInputChange} className="col-span-3" disabled={formLoading} />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="content_type" className="text-right">Type</Label>
              {/* Replace with Select if more types are added */}
              <Input id="content_type" value={formData.content_type} onChange={handleInputChange} className="col-span-3" disabled={formLoading} placeholder="e.g., announcement, offer"/>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="target_audience" className="text-right">Audience</Label>
              {/* Replace with Select if more audiences are added */}
              <Input id="target_audience" value={formData.target_audience} onChange={handleInputChange} className="col-span-3" disabled={formLoading} placeholder="e.g., all, patients, providers"/>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline" disabled={formLoading}>Cancel</Button>
            </DialogClose>
            <Button type="button" onClick={handleFormSubmit} disabled={formLoading}>
              {formLoading ? 'Saving...' : 'Save Content'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

