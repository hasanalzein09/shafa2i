// /home/ubuntu/shafa2i_project/frontend/admin-web/src/app/page.tsx (Dashboard)
// Similar structure to provider dashboard, but uses admin-specific stats

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { getAdminDashboardStats } from '@/services/apiClient'; // Import actual API function

export default function AdminDashboardPage() {
  const { toast } = useToast();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchStats = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching admin dashboard stats...');
      // Use actual API call
      const data = await getAdminDashboardStats();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch dashboard stats:', err);
      const errorMsg = err.response?.data?.detail || 'Failed to load dashboard data.';
      setError(errorMsg);
      toast({ title: "Error Loading Stats", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
      // Simulate some stats on error for layout purposes
      setStats({ total_users: 'N/A', pending_registrations: 'N/A', total_providers: 'N/A', total_pharmacies: 'N/A' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

      {error && <p className="text-red-500 mb-4">Error: {error}</p>}

      {loading ? (
        <p>Loading dashboard...</p>
      ) : stats ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Adjust keys based on actual API response */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              {/* Optional Icon */}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_users ?? 'N/A'}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Registrations</CardTitle>
              {/* Optional Icon */}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pending_registrations ?? 'N/A'}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Providers</CardTitle>
              {/* Optional Icon */}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_providers ?? 'N/A'}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Pharmacies</CardTitle>
              {/* Optional Icon */}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_pharmacies ?? 'N/A'}</div>
            </CardContent>
          </Card>
          {/* Add more cards for other stats if available */}
        </div>
      ) : (
        !error && <p>Could not load dashboard data.</p>
      )}

      {/* TODO: Add quick links or recent activity feed */}
    </div>
  );
}

