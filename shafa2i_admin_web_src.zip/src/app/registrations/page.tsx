// /home/ubuntu/shafa2i_project/frontend/admin-web/src/app/registrations/page.tsx
// Page for approving or rejecting provider/pharmacy registrations

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { getPendingRegistrations, approveRegistration, rejectRegistration } from '@/services/apiClient'; // Import actual API functions

export default function AdminRegistrationsPage() {
  const { toast } = useToast();
  const [registrations, setRegistrations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [processingId, setProcessingId] = useState(null); // Track which registration is being processed

  const fetchRegistrations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching pending registrations...');
      // Use actual API call
      const data = await getPendingRegistrations();
      setRegistrations(data || []); // Ensure it's an array
    } catch (err) {
      console.error('Failed to fetch registrations:', err);
      const errorMsg = err.response?.data?.detail || 'Failed to load pending registrations.';
      setError(errorMsg);
      toast({ title: "Error Loading Registrations", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchRegistrations();
  }, [fetchRegistrations]);

  const handleApprove = async (regId) => {
    setProcessingId(regId);
    try {
      console.log(`Approving registration ${regId}...`);
      // Use actual API call
      await approveRegistration(regId);
      toast({ title: "Registration Approved", description: "The user account has been activated." });
      fetchRegistrations(); // Refresh list
    } catch (err) {
      console.error('Failed to approve registration:', err);
      const errorMsg = err.response?.data?.detail || 'Could not approve registration.';
      toast({ title: "Approval Failed", description: errorMsg, variant: "destructive" });
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (regId) => {
    setProcessingId(regId);
    try {
      console.log(`Rejecting registration ${regId}...`);
      // Use actual API call
      await rejectRegistration(regId);
      toast({ title: "Registration Rejected", description: "The registration request has been rejected." });
      fetchRegistrations(); // Refresh list
    } catch (err) {
      console.error('Failed to reject registration:', err);
      const errorMsg = err.response?.data?.detail || 'Could not reject registration.';
      toast({ title: "Rejection Failed", description: errorMsg, variant: "destructive" });
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Pending Registrations</h1>

      {error && <p className="text-red-500 mb-4">Error: {error}</p>}

      <Card>
        <CardHeader>
          <CardTitle>Approve New Providers & Pharmacies</CardTitle>
          <CardDescription>Review and approve or reject new registration requests.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading registrations...</p>
          ) : registrations.length === 0 ? (
            <p>No pending registrations found.</p>
          ) : (
            <div className="space-y-4">
              {/* Adjust fields based on actual API response structure */}
              {/* Assuming API returns user objects with pending status */}
              {registrations.map((reg) => (
                <Card key={reg.id} className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <p className="font-medium">{reg.name || 'N/A'}</p>
                    <p className="text-sm text-muted-foreground">{reg.phone_number}</p>
                    <p className="text-sm text-muted-foreground">Role: <span className="capitalize">{reg.role}</span></p>
                    {/* Display other relevant info like specialty or address if available */}
                    {reg.role === 'provider' && reg.provider_details?.specialty && (
                        <p className="text-sm text-muted-foreground">Specialty: {reg.provider_details.specialty}</p>
                    )}
                    {reg.role === 'pharmacy' && reg.pharmacy_details?.address && (
                        <p className="text-sm text-muted-foreground">Address: {reg.pharmacy_details.address}</p>
                    )}
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleReject(reg.id)}
                      disabled={processingId === reg.id}
                    >
                      {processingId === reg.id ? 'Processing...' : 'Reject'}
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleApprove(reg.id)}
                      disabled={processingId === reg.id}
                    >
                      {processingId === reg.id ? 'Processing...' : 'Approve'}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

