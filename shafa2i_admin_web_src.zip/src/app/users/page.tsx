// /home/ubuntu/shafa2i_project/frontend/admin-web/src/app/users/page.tsx
// Page for managing all users in the system

'use client';

import React, { useState, useEffect, useCallback } from 'react';

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import { getAllUsers, updateUserRoleStatus } from '@/services/apiClient'; // Import actual API functions

export default function AdminUsersPage() {
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updatingUser, setUpdatingUser] = useState(null); // Track which user is being updated

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching all users...');
      // Use actual API call
      const data = await getAllUsers();
      setUsers(data || []); // Ensure it's an array
    } catch (err) {
      console.error('Failed to fetch users:', err);
      const errorMsg = err.response?.data?.detail || 'Failed to load user list.';
      setError(errorMsg);
      toast({ title: "Error Loading Users", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleUpdate = async (userId, field, value) => {
    setUpdatingUser(userId);
    const currentUser = users.find(u => u.id === userId);
    if (!currentUser) return;

    // Prepare update data based on the field changed
    let updateData = {};
    if (field === 'role') {
      updateData = { role: value, is_active: currentUser.is_active };
    } else if (field === 'is_active') {
      updateData = { role: currentUser.role, is_active: value };
    }

    try {
      console.log(`Updating user ${userId}:`, updateData);
      // Use actual API call
      await updateUserRoleStatus(userId, updateData);
      toast({ title: "User Updated", description: `User ${field} updated successfully.` });
      fetchUsers(); // Refresh list after update
    } catch (err) {
      console.error('Failed to update user:', err);
      const errorMsg = err.response?.data?.detail || 'Could not update user.';
      toast({ title: "Update Failed", description: errorMsg, variant: "destructive" });
      // Revert UI change on error? Or rely on fetchUsers to refresh?
    } finally {
      setUpdatingUser(null);
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">User Management</h1>

      {error && <p className="text-red-500 mb-4">Error: {error}</p>}

      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>View and manage user roles and statuses.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading users...</p>
          ) : users.length === 0 ? (
            <p>No users found.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone Number</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  {/* Add more relevant columns if needed */}
                </TableRow>
              </TableHeader>
              <TableBody>
                {/* Adjust fields based on actual API response structure */}
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name || 'N/A'}</TableCell>
                    <TableCell>{user.phone_number}</TableCell>
                    <TableCell>
                      <Select
                        value={user.role}
                        onValueChange={(newRole) => handleUpdate(user.id, 'role', newRole)}
                        disabled={updatingUser === user.id}
                      >
                        <SelectTrigger className="w-[120px]">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="patient">Patient</SelectItem>
                          <SelectItem value="provider">Provider</SelectItem>
                          <SelectItem value="pharmacy">Pharmacy</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={user.is_active}
                        onCheckedChange={(newStatus) => handleUpdate(user.id, 'is_active', newStatus)}
                        disabled={updatingUser === user.id}
                        aria-label={user.is_active ? 'Deactivate User' : 'Activate User'}
                      />
                      <span className="ml-2 text-sm">{user.is_active ? 'Active' : 'Inactive'}</span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

