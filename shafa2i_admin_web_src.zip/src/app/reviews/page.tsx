// /home/ubuntu/shafa2i_project/frontend/admin-web/src/app/reviews/page.tsx
// Page for managing all reviews across the platform

'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Star } from 'lucide-react'; // Assuming lucide-react for icons
import { useToast } from "@/components/ui/use-toast";
import { getAllReviews, deleteReview } from '@/services/apiClient'; // Import actual API functions

export default function AdminReviewsPage() {
  const { toast } = useToast();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deletingId, setDeletingId] = useState(null); // Track which review is being deleted

  const fetchReviews = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      console.log('Fetching all reviews...');
      // Use actual API call
      const data = await getAllReviews();
      setReviews(data || []); // Ensure it's an array
    } catch (err) {
      console.error('Failed to fetch reviews:', err);
      const errorMsg = err.response?.data?.detail || 'Failed to load reviews.';
      setError(errorMsg);
      toast({ title: "Error Loading Reviews", description: errorMsg, variant: "destructive" });
      // Handle 401 etc. (Interceptor might handle this)
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  const handleDelete = async (reviewId) => {
    if (!confirm('Are you sure you want to delete this review? This cannot be undone.')) return;

    setDeletingId(reviewId);
    try {
      console.log(`Deleting review ${reviewId}...`);
      // Use actual API call
      await deleteReview(reviewId);
      toast({ title: "Review Deleted", description: "The review has been removed." });
      fetchReviews(); // Refresh list
    } catch (err) {
      console.error('Failed to delete review:', err);
      const errorMsg = err.response?.data?.detail || 'Could not delete review.';
      toast({ title: "Deletion Failed", description: errorMsg, variant: "destructive" });
    } finally {
      setDeletingId(null);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`h-4 w-4 ${i <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
        />
      );
    }
    return <div className="flex items-center">{stars}</div>;
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">Review Management</h1>

      {error && <p className="text-red-500 mb-4">Error: {error}</p>}

      <Card>
        <CardHeader>
          <CardTitle>All Platform Reviews</CardTitle>
          <CardDescription>Monitor and manage reviews submitted by patients.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading reviews...</p>
          ) : reviews.length === 0 ? (
            <p>No reviews found on the platform.</p>
          ) : (
            <div className="space-y-4">
              {/* Adjust fields based on actual API response */}
              {reviews.map((review) => (
                <Card key={review.id} className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex-grow">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-medium">{review.patient?.user?.name || review.patient?.name || 'Anonymous'}</span>
                      <span className="text-xs text-muted-foreground">{new Date(review.created_at).toLocaleString()}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">
                      Review for: {review.provider?.user?.name || review.provider?.name || review.pharmacy?.name || 'Unknown Target'}
                      {' '}(<span className="capitalize">{review.provider ? 'Provider' : review.pharmacy ? 'Pharmacy' : 'N/A'}</span>)
                    </p>
                    <div className="flex items-center mb-2">
                      {renderStars(review.rating)}
                    </div>
                    <p className="text-sm">{review.comment || 'No comment provided.'}</p>
                  </div>
                  <div className="flex-shrink-0">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(review.id)}
                      disabled={deletingId === review.id}
                    >
                      {deletingId === review.id ? 'Deleting...' : 'Delete Review'}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

