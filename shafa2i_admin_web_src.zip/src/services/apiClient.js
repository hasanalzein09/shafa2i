// /home/ubuntu/shafa2i_project/frontend/admin-web/src/services/apiClient.js
import axios from 'axios';
import { toast } from "@/components/ui/use-toast"; // Assuming shadcn/ui toast

// TODO: Replace with actual backend API URL from environment variables or config
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1'; // Placeholder

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Function to load token from storage (e.g., localStorage)
export const loadAuthToken = () => {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('authToken');
    }
    return null;
};

// Function to set authorization token
export const setAuthToken = (token) => {
  if (token) {
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    if (typeof window !== 'undefined') {
        localStorage.setItem('authToken', token);
    }
  } else {
    delete apiClient.defaults.headers.common['Authorization'];
    if (typeof window !== 'undefined') {
        localStorage.removeItem('authToken');
    }
  }
};

// Add a request interceptor to include the token from storage on every request
apiClient.interceptors.request.use(config => {
    const token = loadAuthToken();
    if (token && !config.headers.Authorization) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, error => {
    return Promise.reject(error);
});

// Add a response interceptor for handling common errors like 401
apiClient.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      console.error("Unauthorized or Session Expired. Logging out.");
      setAuthToken(null); // Clear token
      // Redirect to login page - This needs to be handled in the component or context
      // Example: window.location.href = '/login';
      toast({ title: "Session Expired", description: "Please log in again.", variant: "destructive" });
    }
    // Log detailed error
    console.error(
        `API Error: ${error.config.method.toUpperCase()} ${error.config.url}`,
        error.response ? `Status: ${error.response.status}` : '',
        error.response ? `Data: ${JSON.stringify(error.response.data)}` : error.message
    );
    return Promise.reject(error);
  }
);

// --- Authentication Endpoints (Admin) ---

export const requestOtp = async (phoneNumber) => {
  // Assuming admin login uses OTP, adjust if different (e.g., email/password)
  const response = await apiClient.post('/auth/otp/request', { phone_number: phoneNumber, user_type: 'admin' }); // Specify user_type
  return response.data;
};

export const verifyOtp = async (phoneNumber, otp) => {
  // Assuming admin login uses OTP
  const response = await apiClient.post('/auth/otp/verify', { phone_number: phoneNumber, otp: otp, user_type: 'admin' }); // Specify user_type
  if (response.data.access_token) {
    setAuthToken(response.data.access_token);
  }
  return response.data;
};

export const logout = () => {
    setAuthToken(null);
    console.log("Logged out, token removed.");
};

// --- Admin: User Management Endpoints ---
export const getAllUsers = async () => {
    const response = await apiClient.get('/admin/users/');
    return response.data;
};

export const updateUserRoleStatus = async (userId, userData) => {
    // Example: userData = { role: 'provider', is_active: true }
    const response = await apiClient.patch(`/admin/users/${userId}/`, userData);
    return response.data;
};

// --- Admin: Registration Approval Endpoints ---
export const getPendingRegistrations = async () => {
    const response = await apiClient.get('/admin/registrations/');
    return response.data;
};

export const approveRegistration = async (registrationId) => {
    const response = await apiClient.post(`/admin/registrations/${registrationId}/approve/`);
    return response.data;
};

export const rejectRegistration = async (registrationId) => {
    const response = await apiClient.post(`/admin/registrations/${registrationId}/reject/`);
    return response.data;
};

// --- Admin: Content Management Endpoints ---
export const getContentItems = async () => {
    const response = await apiClient.get('/admin/content/');
    return response.data;
};

export const addContentItem = async (contentData) => {
    const response = await apiClient.post('/admin/content/', contentData);
    return response.data;
};

export const updateContentItem = async (contentId, contentData) => {
    const response = await apiClient.patch(`/admin/content/${contentId}/`, contentData);
    return response.data;
};

export const deleteContentItem = async (contentId) => {
    await apiClient.delete(`/admin/content/${contentId}/`);
};

// --- Admin: Review Management Endpoints ---
export const getAllReviews = async () => {
    const response = await apiClient.get('/admin/reviews/');
    return response.data;
};

export const deleteReview = async (reviewId) => {
    await apiClient.delete(`/admin/reviews/${reviewId}/`);
};

// --- Admin: Dashboard/Stats Endpoints ---
export const getAdminDashboardStats = async () => {
    // Assuming an endpoint for admin-specific stats
    const response = await apiClient.get('/admin/dashboard/'); // Placeholder endpoint
    return response.data;
};


export default apiClient;

